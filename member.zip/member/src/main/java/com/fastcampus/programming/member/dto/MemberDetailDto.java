package com.fastcampus.programming.member.dto;

import com.fastcampus.programming.member.entity.Member;
import com.fastcampus.programming.member.entity.Team;
import lombok.*;

import javax.validation.constraints.NotNull;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MemberDetailDto {
    private Long id;
    private String firstName;
    private String lastName;
    private String address;
    private String joinedDate;
    private Long team;

    public static MemberDetailDto fromEntity(Member member) {
        return MemberDetailDto.builder()
                .id(member.getId())
                .firstName(member.getFirstName())
                .lastName(member.getLastName())
                .address(member.getAddress())
                .joinedDate(member.getJoinedDate())
                .team(member.getTeam())
                .build();

    }

}
