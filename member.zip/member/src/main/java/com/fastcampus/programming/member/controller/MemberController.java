package com.fastcampus.programming.member.controller;


import com.fastcampus.programming.member.dto.CreateMember;
import com.fastcampus.programming.member.dto.EditMember;
import com.fastcampus.programming.member.dto.MemberDetailDto;
import com.fastcampus.programming.member.dto.MemberDto;
import com.fastcampus.programming.member.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor

public class MemberController {

    private final MemberService memberService;

    @GetMapping("/members")
    public List<MemberDto> getAllMembers() {
        log.info("GET /members HTTP/1.1");

        return memberService.getAllMembers();
    }

    @GetMapping("/member/{id}")
    public MemberDetailDto getMemberDetail(
            @PathVariable Long id
    ) {
        log.info("GET /member/{memberId} HTTP/1.1");

        return memberService.getMemberDetail(id);
    }


    @PostMapping("/create-member")
    public CreateMember.Response createMembers(
            @Valid @RequestBody CreateMember.Request request
    ) {
        log.info("request : {}", request);
        return memberService.createMember(request);
    }

    @PutMapping("/member/{id}")
    public MemberDetailDto editMember(
            @PathVariable Long id,
            @Valid @RequestBody EditMember.Request request
    ) {
        log.info("GET /members HTTP/1.1");

        return memberService.editMember(id, request);
    }


    @DeleteMapping("/member/{memberId}")
    public MemberDetailDto deleteDeveloper(
            @PathVariable Long memberId
    ) {
        log.info("Delete /members HTTP/1.1");

        return memberService.deleteMember(memberId);
    }
}
