package com.fastcampus.programming.member.dto;

import com.fastcampus.programming.member.entity.Team;
import lombok.*;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class EditMember {

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @ToString
    public static class Request{

        @NotNull
        private String firstName;
        @NotNull
        private String lastName;

        @NotNull
        private String address;

        @NotNull
        private String joinedDate;

        @NotNull
        private Long team;
    }

}
