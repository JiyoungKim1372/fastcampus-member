package com.fastcampus.programming.member.dto;

import com.fastcampus.programming.member.entity.Member;
import com.fastcampus.programming.member.entity.Team;
import lombok.*;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CreateMember {
    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @ToString
    public static class Request{


        @NotNull
        @Size(max =255, message = "firstName size must under 255")
        private String firstName;
        @NotNull
        @Size(max =255, message = "lastName size must under 255")
        private String lastName;

        @NotNull
        @Size(max =255, message = "address size must under 255")
        private String address;

        @NotNull
        @Size(min=8, max =8, message = "joinedDate size must 8")
        private String joinedDate;

        @NotNull
        private Long team;

        }



    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Response{
        private String firstName;
        private String lastName;
        private String address;
        private String joinedDate;
        private Long team;

        public static Response fromEntity(Member member) {
            return Response.builder()
                    .firstName(member.getFirstName())
                    .lastName(member.getLastName())
                    .address(member.getAddress())
                    .joinedDate(member.getJoinedDate())
                    .team(member.getTeam())
                    .build();
        }
    }

}



