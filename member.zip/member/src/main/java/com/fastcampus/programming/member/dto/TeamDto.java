package com.fastcampus.programming.member.dto;

import com.fastcampus.programming.member.entity.Member;
import com.fastcampus.programming.member.entity.Team;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TeamDto {
    private Long id;
    private String name;
    private String location;
    private String foundedDate;

    public static TeamDto fromEntity(Team team) {
        return TeamDto.builder()
                .id(team.getId())
                .name(team.getName())
                .location(team.getLocation())
                .foundedDate(team.getFoundedDate())
                .build();

    }

}
