package com.fastcampus.programming.member.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;


@Getter
@AllArgsConstructor
public enum MemberErrorCode {
    NO_MEMBER("해당되는 멤버가 없습니다. "),
    NO_TEAM("해당되는 팀이 없습니다. "),
    DUPLICATED_MEMBER_ID("MemberID가 중복되는 멤버가 있습니다."),
    INTERNAL_SERVER_ERROR("서버에 오류가 발생했습니다."),
    INVALID_REQUEST("잘못된 요청입니다.")
    ;

    private final String message;

}
