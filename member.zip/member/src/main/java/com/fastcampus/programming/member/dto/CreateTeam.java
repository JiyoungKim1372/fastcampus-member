package com.fastcampus.programming.member.dto;

import com.fastcampus.programming.member.entity.Team;
import lombok.*;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CreateTeam {

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @ToString
    public static class Request{

        @NotNull
        private String name;
        @NotNull
        private String location;
        @NotNull
        private String foundedDate;
    }



    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Response{

        private Long id;
        private String name;
        private String location;
        private String foundedDate;

        public static CreateTeam.Response fromEntity(Team team) {
            return Response.builder()
                    .id(team.getId())
                    .name(team.getName())
                    .location(team.getLocation())
                    .foundedDate(team.getFoundedDate())
                    .build();
        }
    }
}
