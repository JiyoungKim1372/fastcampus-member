package com.fastcampus.programming.member.service;

import com.fastcampus.programming.member.dto.*;
import com.fastcampus.programming.member.entity.Member;
import com.fastcampus.programming.member.entity.Team;
import com.fastcampus.programming.member.exception.MemberException;
import com.fastcampus.programming.member.repository.TeamRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

import static com.fastcampus.programming.member.exception.MemberErrorCode.NO_MEMBER;

@Service
@RequiredArgsConstructor

public class TeamService {
    private final TeamRepository teamRepository;

    @Transactional
    public CreateTeam.Response createTeam(CreateTeam.Request request) {

        Team team = Team.builder()
                .name(request.getName())
                .location(request.getLocation())
                .foundedDate(request.getFoundedDate())
                .build();

        teamRepository.save(team);
        return CreateTeam.Response.fromEntity(team);
    }

    public List<TeamDto> getAllTeams() {
        return teamRepository.findAll()
                .stream().map(TeamDto::fromEntity)
                .collect(Collectors.toList());
    }


}
