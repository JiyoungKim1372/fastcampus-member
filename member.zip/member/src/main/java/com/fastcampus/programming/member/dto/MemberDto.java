package com.fastcampus.programming.member.dto;


import com.fastcampus.programming.member.entity.Member;
import com.fastcampus.programming.member.entity.Team;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MemberDto {

    private String firstName;
    private String lastName;
    private String address;
    private String joinedDate;
    private Long team;

    public static MemberDto fromEntity(Member member) {
        return MemberDto.builder()
                .firstName(member.getFirstName())
                .lastName(member.getLastName())
                .address(member.getAddress())
                .joinedDate(member.getJoinedDate())
                .team(member.getTeam())
                .build();

    }
}
