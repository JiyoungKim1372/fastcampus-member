package com.fastcampus.programming.member.controller;


import com.fastcampus.programming.member.dto.CreateMember;
import com.fastcampus.programming.member.dto.CreateTeam;
import com.fastcampus.programming.member.dto.MemberDto;
import com.fastcampus.programming.member.dto.TeamDto;
import com.fastcampus.programming.member.entity.Team;
import com.fastcampus.programming.member.service.TeamService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
public class TeamController {
    private final TeamService teamService;

    @GetMapping("/teams")
    public List<TeamDto> getAllTeams() {
        log.info("GET /teams HTTP/1.1");
        return teamService.getAllTeams();
    }

    @PostMapping("/create-team")
    public CreateTeam.Response createTeam(
            @Valid @RequestBody CreateTeam.Request request
    ) {
        log.info("request : {}", request);
        return teamService.createTeam(request);
    }


}
