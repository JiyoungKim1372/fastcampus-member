package com.fastcampus.programming.member.service;


import com.fastcampus.programming.member.dto.*;
import com.fastcampus.programming.member.entity.Member;
import com.fastcampus.programming.member.exception.MemberException;
import com.fastcampus.programming.member.repository.MemberRepository;
import com.fastcampus.programming.member.repository.TeamRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

import static com.fastcampus.programming.member.exception.MemberErrorCode.NO_MEMBER;
import static com.fastcampus.programming.member.exception.MemberErrorCode.NO_TEAM;

@Service
@RequiredArgsConstructor
public class MemberService {
    private final MemberRepository memberRepository;
    private final TeamRepository teamRepository;

    private final EntityManager em;


    @Transactional
    public CreateMember.Response createMember(CreateMember.Request request) {
        validateCreateMemberRequest(request);

        Member member = Member.builder()
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .address(request.getAddress())
                .joinedDate(request.getJoinedDate())
                .team(request.getTeam())
                .build();

        memberRepository.save(member);
        return CreateMember.Response.fromEntity(member);
    }

    private void validateCreateMemberRequest(CreateMember.Request request) {
        Long team = request.getTeam();

        teamRepository.findById(request.getTeam())
                .map(TeamDto::fromEntity)
                .orElseThrow(() -> new MemberException(NO_TEAM));
    }

    public List<MemberDto> getAllMembers() {
        return memberRepository.findAll()
                .stream().map(MemberDto::fromEntity)
                .collect(Collectors.toList());
    }

    public MemberDetailDto getMemberDetail(Long id) {
        return memberRepository.findById(id)
                .map(MemberDetailDto::fromEntity)
                .orElseThrow(() -> new MemberException(NO_MEMBER));
    }

    @Transactional
    public MemberDetailDto editMember(Long id, EditMember.Request request) {

        Member member = memberRepository.findById((id)).orElseThrow(
                () -> new MemberException(NO_MEMBER)
        );

        member.setFirstName(request.getFirstName());
        member.setLastName(request.getLastName());
        member.setAddress(request.getAddress());
        member.setTeam(request.getTeam());

        return MemberDetailDto.fromEntity(member);
    }


    public MemberDetailDto deleteMember(Long id) {
        memberRepository.deleteById(id);
        System.out.println("deleted");
        return null;
    }



}
