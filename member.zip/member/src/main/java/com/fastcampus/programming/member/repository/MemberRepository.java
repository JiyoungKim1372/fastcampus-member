package com.fastcampus.programming.member.repository;

import com.fastcampus.programming.member.entity.Member;
import org.apache.el.stream.Stream;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {

    //static Optional<Member> findById(String id);

}
