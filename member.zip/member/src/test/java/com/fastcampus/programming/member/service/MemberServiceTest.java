package com.fastcampus.programming.member.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MemberServiceTest {

    @Test
    void createMember() {

    }

    @Test
    void getAllMembers() {
    }

    @Test
    void getMemberDetail() {
    }

    @Test
    void editMember() {
    }

    @Test
    void deleteMember() {
    }
}